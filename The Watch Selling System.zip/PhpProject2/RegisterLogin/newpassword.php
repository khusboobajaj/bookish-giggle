<?php
session_start();
include '../connection.php';
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
  <head>
    <meta charset="utf-8">
    <title>Set new Password</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="../css/home.css" media="screen" title="no title" charset="utf-8">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style media="screen">
      body {
        background-image: url("../images/bnr-2.jpg");
      }
      .jumbotron {
        width: 37%;
        margin: auto;
      }
      #errormsg{
      	width:40%;
      	margin: 30px auto;
      	border: 1px solid #FF0000;
      	background: #FFB9B8;
      	color: #FF0000;
      	text-align: center;
      	padding: 10px 0;
      }
      .navbar-custom {
        color: #FFFFFF;
        background-color: #001;
      }
      a {
        color: grey;
      }
      .active {
        color:white;
        font-size: 1.1em;
      }
      a:hover {
        color:#f1f1f1;
      }
      .navbar-brand{
        font-size: 1.5em;
        color:#f1f1f1;
      }
      .custom-toggler.navbar-toggler {
        padding:1px;
        background-image: url("../images/menu.svg");
        filter: invert(1);
      }
      .form-control{
        border-radius: 200px;
      }
      ::-webkit-scrollbar {
        width: 10px;
      }
      ::-webkit-scrollbar-track {
        box-shadow: inset 0 0 1px rgb(0, 0, 0);
      }
      ::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 10px;
      }
      ::-webkit-scrollbar-thumb:hover {
        background: powderblue;
      }
    </style>
  </head>
  <body>
    <nav class="navbar sticky-top navbar-expand-lg navbar-custom ">
      <div class="container">
        <a class="navbar-brand" href="#">The Watch Store</a>
        <button class="custom-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-item nav-link" href="../home.php">Home</a>
          </div>
          <div class="navbar-nav">
            <a class="nav-item nav-link" href="../product.php">Product</a>
          </div>
          <div class="navbar-nav ml-auto">
              <a class="nav-item nav-link" href="register.php">Sign Up&nbsp; <i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp;&nbsp;</a>
              <a class="nav-item nav-link" href="../bill.php"><i class="fa fa-shopping-bag" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>
    </nav>
      
      <div class="header">
      <h1 style='text-align:center;padding:20px 0;color:#f1f1f1;background-color:rgba(0,0,0,.5);margin:0 0;'>Welcome to Watch Store</h1>
    </div>

    <div class="jumbotron">
      <center><form  method="post">
        <div class="imgcontainer">
          <img style="border-radius:50%;width:7.0em;height:auto;" src="../images/key.png" alt="login" />
        </div>
        <table width="430px">
          <tr>
            <th>Set New Password</th>
          </tr>
          <tr>
              <td><input class="form-control" type="password" name="newpassword" placeholder="Enter new password" required=""></td>
          </tr>
          <tr>
              <td><input class="form-control" type="password" name="confirmpassword" placeholder="Confirm password" required=""></td>
          </tr>
          <tr><td></td></tr>
          <tr><td></td></tr>
          <tr>
            <td><input style="width:100%" class="form-control btn btn-primary" type="submit" name="submit" value="Set password"></td>
          </tr>
        </table>
      </form></center>
    </div>

 <footer class="py-5 bg-light mt-auto">
                    <div class="container-fluid">
                            <center><div class="text-muted">Copyright &copy; watch store 2021</div></center>
                    </div>
    </footer>
      <?php
        if(isset($_REQUEST['submit']))
        {
            $new=$_POST['newpassword'];
            $new= md5($new);
            $confirm=$_POST['confirmpassword'];
            $confirm= md5($confirm);
            $emailid=$_SESSION['emailid'];
            if($new==$confirm)
            {
                $str=mysqli_query($conn,"update tbl_user set Password='".$new."' where Email_id='".$emailid."'");
                echo "<script>window.location='login.php'</script>";
            }else
            {
                echo '<script>alert("Incorrect Confirm Password please try again!!!")</script>';
                echo "<script>window.location='newpassword.php'</script>";
            }
        }
        ?>
  </body>
</html>

