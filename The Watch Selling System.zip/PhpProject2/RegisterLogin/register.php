<?php
include '../connection.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Register</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <link rel="stylesheet" href="../css/home.css" media="screen" title="no title" charset="utf-8">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#state").change(function () {
                    $.ajax({
                        url: "getcity.php",
                        type: "POST",
                        data: {id: $("#state").val(), },
                        success: function (data) {
                            $("#city").html(data)
                        }
                    });
                });
            });
        </script>
        <style media="screen">
            body {
                background-image: url("../images/1.jpg");
            }
            .jumbotron {
                width: 37%;
                margin: auto;
            }
            #errormsg{
                width:40%;
                margin: 30px auto;
                border: 1px solid #FF0000;
                background: #FFB9B8;
                color: #FF0000;
                text-align: center;
                padding: 10px 0;
            }
            .navbar-custom {
                color: #FFFFFF;
                background-color: #001;
            }
            a {
                color: grey;
            }
            .active {
                color:white;
                font-size: 1.1em;
            }
            a:hover {
                color:#f1f1f1;
            }
            .navbar-brand{
                font-size: 1.5em;
                color:#f1f1f1;
            }
            .custom-toggler.navbar-toggler {
                padding:1px;
                background-image: url("../images/menu.svg");
                filter: invert(1);
            }
            .form-control{
                border-radius: 25px;
            }
            ::-webkit-scrollbar {
                width: 10px;
            }
            ::-webkit-scrollbar-track {
                box-shadow: inset 0 0 1px rgb(0, 0, 0);
            }
            ::-webkit-scrollbar-thumb {
                background: rgba(0, 0, 0, 0.2);
                border-radius: 10px;
            }
            ::-webkit-scrollbar-thumb:hover {
                background: powderblue;
            }
            .selectWrapper{
                border-radius:36px;
                display:inline-block;
                overflow:hidden;
                border:1px;
            }
            .selectBox{
                width:140px;
                height:40px;
                border:0px;
                outline:none;
            }
            .textarea 
            {
                border-radius: 25px;
                border: 1px;
                width:400px; 
                height:100px;
            }
            .dob
            {
                border-radius: 25px;
                border: 1px;
                width:200px; 
                height:35px;
            }
            .error{
                color:red;
            }
        </style>
    </head>
    <body>
        <nav class="navbar sticky-top navbar-expand-lg navbar-custom ">
            <div class="container">
                <a class="navbar-brand" href="#">The Watch Store</a>
                <button class="custom-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-item nav-link" href="../home.php">Home</a>
                    </div>
                    <div class="navbar-nav ml-auto">
                        <a class="nav-item nav-link" href="login.php">Login&nbsp; <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;</a>
                        <a class="nav-item nav-link" href="login.php"><i class="fa fa-shopping-bag" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </nav>
        <?php
        // The preg_match() function searches a string for pattern, returning
        //   true if the pattern exists, and false otherwise.
        /*$nameErr = $pincodeErr = $emailErr = $addressErr = $cityErr = $stateErr = $contactErr = $usernameErr = $passwordErr = $dobErr = "";
        $name = $pincode = $addre = $City = $State = $email = $gender1 = $Contact = $username = $password = $dob = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["name"])) {
                $nameErr = "Name is required";
            } else {
                $name = test_input($_POST["name"]);
            }
            if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
                $nameErr = "Only letters and white space allowed";
            }

            if (empty($_POST["pincode"])) {
                $pincodeErr = "Pincode is required";
            } else {
                $pincode = test_input($_POST["pincode"]);
            }
            if (!preg_match("/^[6-9]{1}[0-9]{4}+[1-9]{1}/", $pincode)) {
                $pincodeErr = "Only six numbers are allowed";
            }

            if (empty($_POST["address"])) {
                $addressErr = "Address is required";
            } else {
                $addre = test_input($_POST["address"]);
            }

            if (empty($_POST["city"])) {
                $cityErr = "City is required";
            } else {
                $City = test_input($_POST["city"]);
            }

            if (empty($_POST["state"])) {
                $stateErr = "State is required";
            } else {
                $State = test_input($_POST["state"]);
            }


            if (empty($_POST["email"])) {
                $emailErr = "Email is required";
            } else {
                $email = test_input($_POST["email"]);
                // check if e-mail address is well-formed
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $emailErr = "Invalid email format";
                }
            }
            if (empty($_POST["contact"])) {
                $contactErr = "Contact Number is required";
            } else {
                $Contact = test_input($_POST["contact"]);
                if (!preg_match("/^[6-9]{1}+[0-9]{8}+[1-9]{1}$/", $Contact)) {
                    $contactErr = "Only numbers are allowed";
                }
            }
            if (empty($_POST["username"])) {
                $usernameErr = "Please set Username";
            } else {
                $username = test_input($_POST["username"]);
            }
            if (empty($_POST["password"])) {
                $passwordErr = "Please create your password";
            } else {
                $password = test_input($_POST["password"]);
            }
            if (!preg_match("/^.{8,}$/", $password)) {
                $passwordErr = "Eight or more charaters only";
            }
            if (empty($_POST["dob"])) {
                $dobErr = "Please select your birth date";
            } else {
                $dob = test_input($_POST["dob"]);
            }

            /* if (empty($_POST["gender"])) {
              $genderErr = "Gender is required";
              } else {
              $gender1 = test_input($_POST["gender"]);
              } 
        }*/

        function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>

        <div class="jumbotron">
            <h2>Sign Up</h2>
            <p>
                Please fill in this form to create an account.
            </p>
            <center><form method="post">
                    <table width="430px">
                        <tr>
                            <th>Name:</th>
                        </tr>
                        <tr>
                            <td><input class="form-control" type="text" name="name" placeholder="Enter Name" required="" pattern="[A-Za-z\s]{2,}" title="Please Enter Valid Name"></td>
                        </tr>
                        <tr>
                            <th>Gender:</th>
                        </tr>
                        <tr>
                            <td><input type="radio" name="gender" value="F" >&nbsp;&nbsp;Female&nbsp;&nbsp;&nbsp;
                                <input type="radio" name="gender" value="M" >&nbsp;&nbsp;Male&nbsp;&nbsp;&nbsp;
                                <input type="radio" name="gender" value="O" >&nbsp;&nbsp;Other&nbsp;&nbsp;&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Address:</th>
                        </tr>
                        <tr>
                            <td><textarea name="address" rows="4" cols="45" class="textarea"  required=""></textarea></td>
                        </tr>
                        <tr>
                            <th>Pincode:</th>
                        </tr>
                        <tr>
                            <td><input class="form-control" type="text" name="pincode" placeholder="Enter Pincode"  class="textInput" required="" pattern="^[1-9]{1}[0-9]{2}{0, 1}[0-9]{3}$" title="Please enetr valid pincode"></td>
                        </tr>


                        <tr>
                            <th>State:</th>
                        </tr>
                        <tr>
                            <td><select id="state" name="state" style=" width:200px; height:35px;" class="selectWrapper" class="selectBox" required="">

                                    <option disabled selected>--select State--</option>
                                    <?php
                                        $result = mysqli_query($conn, "select * from tbl_state");
                                        while ($row = mysqli_fetch_assoc($result)) {
                                    ?>
                                        <option value="<?php echo $row['S_id']; ?>"><?php echo $row['State_name'];?></option>
                                    <?php
                                    }
                                    ?>
                                </select></td>
                        </tr>
                        <tr>
                            <th>City:</th>
                        </tr>
                        <tr>
                            <td><select id="city" name="city" style=" width:200px; height:35px;" class="selectWrapper" class="selectBox" required="">
                                    <option disabled selected>--select city--</option>

                                </select></td>
                        </tr>

                        <tr>
                            <th>Date of Birth:</th>
                        </tr>
                        <tr>
                            <td><input type=date name="dob" max="2003-01-01" required=""></td>
                        </tr>
                        <tr>
                            <th>Email Id:</th>
                        </tr>
                        <tr>
                            <td><input class="form-control" type="email" name="emailid" placeholder="Enter Email Id" required></td>
                        </tr>
                        <tr>
                            <th>Contact Number:</th>
                        </tr>
                        <tr>
                            <td><input class="form-control" type="text" name="contactno" placeholder="Enter Contact Number" pattern="[7-9]{1}[0-9]{9}"
                                       title="Phone number with 7-9 and remaing 9 digit with 0-9" required=""></td>
                        </tr>
                        <tr>
                            <th>Username:</th>
                        </tr>
                        <tr>
                            <td><input class="form-control" type="text" name="username" placeholder="Enter Username" required="" pattern="[A-Za-z0-9]{8,}" title="First letter must be in caps and 8 or more charaters, must contain atleast one digit"></td>
                        </tr>
                        <tr>
                            <th>Password:</th>
                        </tr>
                        <tr>
                            <td><input class="form-control" type="password" name="password" placeholder="Enter Password"  required="" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,}$" title="Please Valid password"></td>
                        </tr>
                        <tr><td></td></tr>
                        <tr><td></td></tr>
                        <tr>
                            <td><input style="width:100%" class="form-control btn btn-primary" type="submit" name="register" value="Sign Up"></td>
                        </tr>
                    </table>
                </form></center>
        </div>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid">
                <center><div class="text-muted">Copyright &copy; watch store 2021</div></center>
            </div>
        </footer>
        <script type="text/javascript" src="../js/validate.js">
        </script>

<?php
if (isset($_POST['register'])) {

        
                $current= date('Y-m-d');
                if($_REQUEST['dob']>=$current)
                {//future
                    echo "<script>alert('Invalid DOB')</script>";
                }
                    
        $sql = mysqli_query($conn, "select Username,Email_id,Contact_no from tbl_user where Username='" . $_POST['username'] . "' or Email_id='" . $_POST['emailid'] . "' or Contact_no='" . $_POST['contactno'] . "'");
        //$count = $conn->query($sql);

        $count = mysqli_num_rows($sql);
        if ($count > 0) {
            echo '<script>alert("Username or email id or contact number is already exists")</script>';
        } else {
            $query = "insert into tbl_user(Name,Gender,Address,Pincode,DOB,Email_id,Contact_no,Username,Password) value('" . $_POST['name'] . "','" . $_POST['gender'] . "','" . $_POST['address'] . "','" . $_POST['pincode'] . "','" . $_POST['dob'] . "','" . $_POST['emailid'] . "','" . $_POST['contactno'] . "','" . $_POST['username'] . "','" . md5($_POST['password']) . "')";
            $result = mysqli_query($conn, $query);
            echo '<script>alert("Succcessfully Insert!" )</script>';
        }
            echo "<script>window.location='login.php'</script>";
        }
     else {
        //echo '<script>alert("not Insert!" )</script>'; 
    }

?>
    </body>
</html>

