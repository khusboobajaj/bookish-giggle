<?php
include '../connection.php';
$sid=$_POST['id'];
$sql="select * from tbl_city where s_id={$sid}";
echo $sql;
$result= mysqli_query($conn, $sql);
?>
        <table width="430px">
         <tr>
              <td><select name="City" style=" width:200px; height:35px;" class="selectWrapper" class="selectBox">
                      <option disabled selected>--select city--</option>
                      <?php 
                            while ($row= mysqli_fetch_assoc($result))
                            {
                                 echo "<option>".$row['city_name']."</option>";
                            }
                      ?>
          </select><span class="error"> <?php echo $cityErr; ?></span></td>
          </tr>
        </table>      
<?php mysqli_close($conn); ?> 


