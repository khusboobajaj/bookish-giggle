var fp5 = document.querySelector('.val');
var fname = fp5[0];
var email = fp5[1];
var password = fp5[3];
var mobile = fp5[2];
var address = fp5[5];
var pincode = fp5[6];
var name_error = document.getElementById('name_error');
var address_error = document.getElementById('address_error');
var password_error = document.getElementById('password_error');
var mobile_error = document.getElementById('mobile_error');
var email_error = document.getElementById('email_error');
var pincode_error = document.getElementById('pincode_error');

fname.addEventListener('blur',nameVerify,true);
address.addEventListener('blur',addressVerify,true);
password.addEventListener('blur',passwordVerify,true);
mobile.addEventListener('blur',mobileVerify,true);
email.addEventListener('blur',emailVerify,true);
pincode.addEventListener('blur',pincodeVerify,true);

function validate(){
  var namereg = new RegExp("^[A-Za-z]{3,20}$");
  var mobreg = new RegExp("^[6-9][0-9]{9}$");
  var emailreg = new RegExp("^([a-z 0-9\.~_]+)@([a-z0-9~]+).([a-z]{2,3})(.[a-z]{2,3})?$");
  if(fname.value == ""){
    fname.style.border = "1px solid red";
    name_error.textContent = "Username Required";
    fname.focus();
    return false;
  }
  if(!namereg.test(fname.value)){
    fname.style.border = "1px solid red";
    name_error.textContent = "Enter Proper Name";
    fname.focus();
    return false;
  }
  if(address.value == ""){
    address.style.border = "1px solid red";
    address_error.textContent = "Address is Required";
    address.focus();
    return false;
  }

  if(password.value == ""){
    password.style.border = "1px solid red";
    password_error.textContent = "Password is Required";
    password.focus();
    return false;
  }
  if(password.value.length < 6){
    password.style.border = "1px solid red";
    password_error.textContent = "Minimum 6 charater Required!";
    password.focus();
    return false;
  }
  if(mobile.value == ""){
    mobile.style.border = "1px solid red";
    mobile_error.textContent = "Address is Required";
    mobile.focus();
    return false;
  }
  if(!mobreg.test(mobile.value)){
    mobile.style.border = "1px solid red";
    mobile_error.textContent = "Enter Proper Mobile Number";
    mobile.focus();
    return false;
  }
  if(email.value == ""){
    email.style.border = "1px solid red";
    email_error.textContent = "Address is Required";
    email.focus();
    return false;
  }
  if(!emailreg.test(email.value)){
    email.style.border = "1px solid red";
    email_error.textContent = "Enter Proper Email";
    email.focus();
    return false;
  }
  if(pincode.value.length != 6 ){
    pincode.style.border = "1px solid red";
    pincode_error.textContent = "Enter Proper Pincode";
    pincode.focus();
    return false;
  }
}

function nameVerify(){
  if(fname.value != ""){
    fname.style.border = "1px solid rgba(0,0,0,0.10)";
    name_error.innerHTML = "";
    return true;
  }
}
function addressVerify(){
  if(address.value != ""){
    address.style.border = "1px solid rgba(0,0,0,0.10)";
    address_error.innerHTML = "";
    return true;
  }
}
function passwordVerify(){
  if(password.value != ""){
    password.style.border = "1px solid rgba(0,0,0,0.10)";
    password_error.innerHTML = "";
    return true;
  }
}
function mobileVerify(){
  if(mobile.value != ""){
    mobile.style.border = "1px solid rgba(0,0,0,0.10)";
    mobile_error.innerHTML = "";
    return true;
  }
}
function emailVerify(){
  if(email.value != ""){
    email.style.border = "1px solid rgba(0,0,0,0.10)";
    email_error.innerHTML = "";
    return true;
  }
}
function pincodeVerify(){
  if(pincode.value != ""){
    pincode.style.border = "1px solid rgba(0,0,0,0.10)";
    pincode_error.innerHTML = "";
    return true;
  }
}
