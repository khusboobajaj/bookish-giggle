<?php
ob_start();
    include './connection.php';
    session_start();
if($_SESSION['username']==NULL)
{
    header("Location:RegisterLogin/login.php");
}


?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/home.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </head>
    <style media="screen">
        
          .navbar-custom {
      color: #FFFFFF;
      background-color: #001;
    }
    a {
      color: grey;
    }
    .active {
      color:white;
      font-size: 1.1em;
    }
    a:hover {
      color:#f1f1f1;
    }
    .navbar-brand{
      font-size: 1.5em;
      color:#f1f1f1;
    }
    .custom-toggler.navbar-toggler {
      padding:1px;
      background-image: url("images/menu.svg");
      filter: invert(1);
    }
     .jumbotron {
      margin: 20px 40px;
    }
    .thumbnail{
      /*margin: 10px 10px;*/
      padding: 10px 10px;
      width: 70%;
      height: auto;
      align-items: center;
    }
    #borderpart{
       border: 1px solid rgba(0, 0, 0, 0.2);
       margin: 6px;
       margin-bottom: 20px;
       width: 24%;
       border-radius: 5%;
    }
    .containers {
      width: 92%;
      margin: auto;
    }
    .cntr{
      align-items: center;
      width: 50%;
    }
    .zoom {
      transition: transform .2s;
    }
    ::-webkit-scrollbar {
      width: 10px;
    }
    ::-webkit-scrollbar-track {
      box-shadow: inset 0 0 1px rgb(0, 0, 0);
    }
    ::-webkit-scrollbar-thumb {
      background: rgba(0, 0, 0, 0.2);
      border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: powderblue;
    }
 
        table,td{
                font-family: sans-serif;
                font-size: small;
                       
                width:750px;
            }
            tr,td,th{ padding: 8px}
            #other
            {
                padding-left: 10px;
                
            }
            th,#pay-info
            {
               border: 1px solid black;
               border-collapse: collapse;
               width: 750px;
            }
    </style>
    <body>
        <nav class="navbar sticky-top navbar-expand-lg navbar-custom ">
      <div class="container">
        <a class="navbar-brand" href="#">The Watch Store</a>
        <button class="custom-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
              <a class="nav-item nav-link" href="CustomerDashboard.php">Home</a>
          </div>
          <div class="navbar-nav">
              <a class="nav-item nav-link" href="userprofile.php">User Profile</a>
          </div>
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="contactUs.php">Contact Us</a>
          </div>
          <div class="navbar-nav ml-auto">
              <a class="nav-item nav-link" href="RegisterLogin/logout.php">Logout&nbsp;<i class="fa fa-sign-out"></i>&nbsp;&nbsp;</a>
              <a class="nav-item nav-link active" href="addtocart.php"><i class="fa fa-shopping-bag" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>
    </nav><br>
        <center>
            <h3>The Watch Store</h3><br><br>
    <table id="info" class="card-text" style="font-family: sans-serif;">
        <?php
            $sql=mysqli_query($conn,"SELECT tbl_product.p_name,tbl_product.price,tbl_orderdetails.quantity,tbl_orderdetails.amount as productamount,
tbl_order.amount as totalamount,tbl_order.order_date,CONCAT(tbl_user.Name) as name,tbl_payment.payment_mode
FROM tbl_reference_order
INNER JOIN tbl_orderdetails ON tbl_orderdetails.od_id=tbl_reference_order.od_id
INNER JOIN tbl_order ON tbl_reference_order.o_id=tbl_order.o_id
INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id
INNER JOIN tbl_user ON tbl_order.u_id=tbl_user.id
INNER JOIN tbl_payment ON tbl_payment.pay_id=tbl_order.pay_id
WHERE tbl_reference_order.o_id='".$_SESSION["oid"]."'");
            while($row= mysqli_fetch_array($sql)){
                $name=$row["name"];
                $orderdate=$row["order_date"];
                $method=$row["payment_mode"];
                $total=$row["totalamount"];
            }
        ?>
            <tr>
                <td><label for="name" style="font-weight: bold">Name</label></td>
                <td><label for="name" n> <?php echo $name;?></label></td>
                
            </tr>
            
            <tr>
                <td><label for="department-name" style="font-weight: bold">Order Date</label></td>
                <td><label><?php echo $orderdate;?></label></td>
                
            </tr>
            <tr>
                <td><label for="days-month" style="font-weight: bold">Payment Method</label></td>
                <td><label><?php echo $method;?></label></td>
                
            </tr>
            
        </table> 
            </center>
        <br><br>
        <center>
        <table id="pay-info">
            <tr>
                <th><label for="earnings" style="font-weight: bold">Product Name</label></th>
                <th><label for="payable" style="font-weight: bold">Price(per quantity)</label></th>
                <th ><label for="deductions" style="font-weight: bold">Quantity</label></th>
                <th><label for="amount" style="font-weight: bold">Amount</label></th>
            </tr> 
            <?php
            $query=mysqli_query($conn,"SELECT tbl_product.p_name,tbl_product.price,tbl_orderdetails.quantity,tbl_orderdetails.amount as productamount,
tbl_order.amount as totalamount,tbl_order.order_date,CONCAT(tbl_user.Name) as name,tbl_payment.payment_mode
FROM tbl_reference_order
INNER JOIN tbl_orderdetails ON tbl_orderdetails.od_id=tbl_reference_order.od_id
INNER JOIN tbl_order ON tbl_reference_order.o_id=tbl_order.o_id
INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id
INNER JOIN tbl_user ON tbl_order.u_id=tbl_user.id
INNER JOIN tbl_payment ON tbl_payment.pay_id=tbl_order.pay_id
WHERE tbl_reference_order.o_id='".$_SESSION["oid"]."'");
            while($r= mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $r["p_name"]; ?></td>
                
                <td style="border-left: 1px solid black"><?php echo $r["price"]; ?></td>
                
                <td style="border-left: 1px solid black"><?php echo $r["quantity"]; ?></td>
                <td style="border-left: 1px solid black"><?php echo $r["productamount"]; ?></td>
                
                
                
            </tr>
            
            
           
            <?php
                }
            ?>
             <tr>
               
                <td style="border-top: 1px solid black; border-bottom: 1px solid white; border-right: 1px solid white; border-left:1px solid white;"></td>
                <td style="border: 1px solid black; border-bottom:1px solid white"></td>
                
                <td style="border: 1px solid black"><label style="font-weight: bold;">Total Amount</label></td>
                <td style="border: 1px solid black"><?php echo $total;?></td>
                
                                
            </tr>
            
        </table><br>
        <form method="post">
        <input type="submit" name="print" value="View As Pdf" class="btn btn-secondary">    
        <input type="submit" name="feedback" value="Give Feedback" class="btn btn-primary">
        </form>
            
</center><br>
        <footer class="py-5 bg-light mt-auto">
                    <div class="container-fluid">
                            <center><div class="text-muted">Copyright &copy; watch store 2021</div></center>
                    </div>
    </footer>
    </body>
</html>
<?php
    if(isset($_POST['print']))
    {
        header("Location:printbill.php");
    }
    else if(isset ($_POST['feedback']))
    {
        header("Location:contactUs.php");
    }
    ob_flush();
?>
