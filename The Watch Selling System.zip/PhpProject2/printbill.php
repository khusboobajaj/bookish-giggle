<?php
ob_start();
    include './connection.php';
    session_start();
if($_SESSION['username']==NULL)
{
    header("Location:RegisterLogin/login.php");
}


?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $sql=mysqli_query($conn,"SELECT tbl_product.p_name,tbl_product.price,tbl_orderdetails.quantity,tbl_orderdetails.amount as productamount,
tbl_order.amount as totalamount,tbl_order.order_date,CONCAT(tbl_user.Name) as name,tbl_payment.payment_mode
FROM tbl_reference_order
INNER JOIN tbl_orderdetails ON tbl_orderdetails.od_id=tbl_reference_order.od_id
INNER JOIN tbl_order ON tbl_reference_order.o_id=tbl_order.o_id
INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id
INNER JOIN tbl_user ON tbl_order.u_id=tbl_user.id
INNER JOIN tbl_payment ON tbl_payment.pay_id=tbl_order.pay_id
WHERE tbl_reference_order.o_id='".$_SESSION["oid"]."'");
            while($row= mysqli_fetch_array($sql)){
                $name=$row["name"];
                $orderdate=$row["order_date"];
                $method=$row["payment_mode"];
                $total=$row["totalamount"];
            }
        ?>
        <?php
            require 'fpdf/fpdf/fpdf.php';
            

        /* A4 width : 219mm */

        $pdf = new FPDF('P', 'mm', 'A4');

        $pdf->AddPage();
        /* output the result */

        /* set font to arial, bold, 14pt */
        $pdf->SetFont('helvetica', 'B', 20);

        /* Cell(width , height , text , border , end line , [align] ) */

        $pdf->Cell(40, 10, '', 0, 0);
//Cell(70,10,'Page Heading',1,0,'C');
        $pdf->Cell(120, 10, 'The Watch Store ',0, 0, 'C');
        $pdf->Cell(59, 10, '', 0, 1);
        $pdf->Cell(59, 10, '', 0, 1);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(30, 5, 'Name:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(70, 5, $name, 0, 0);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 5, '', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(25, 5, '', 0, 0);

        $pdf->Cell(60, 10, '', 0, 1);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 5, 'Payment Method:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(70, 5, $method, 0, 0);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 5, 'Order Date:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(25, 5,$orderdate , 0, 0);

        $pdf->Cell(60, 10, '', 0, 1);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(30, 5, '', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(70, 5, '', 0, 0);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 5, '', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(25, 5, '', 0, 0);

        $pdf->Cell(60, 10, '', 0, 1);

        $pdf->Cell(50, 10, '', 0, 1);

        $pdf->SetFont('Arial', 'B', 12);
        /* Heading Of the table */
        $pdf->Cell(50, 6, 'Product Name', 1, 0, 'C');
        $pdf->Cell(40, 6, 'Price(per quantity)', 1, 0, 'C');
        $pdf->Cell(50, 6, 'Quantity', 1, 0, 'C');
        $pdf->Cell(40, 6, 'Amount', 1, 1, 'C');
        /* Heading Of the table end */

            $query=mysqli_query($conn,"SELECT tbl_product.p_name,tbl_product.price,tbl_orderdetails.quantity,tbl_orderdetails.amount as productamount,
tbl_order.amount as totalamount,tbl_order.order_date,CONCAT(tbl_user.Name) as name,tbl_payment.payment_mode
FROM tbl_reference_order
INNER JOIN tbl_orderdetails ON tbl_orderdetails.od_id=tbl_reference_order.od_id
INNER JOIN tbl_order ON tbl_reference_order.o_id=tbl_order.o_id
INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id
INNER JOIN tbl_user ON tbl_order.u_id=tbl_user.id
INNER JOIN tbl_payment ON tbl_payment.pay_id=tbl_order.pay_id
WHERE tbl_reference_order.o_id='".$_SESSION["oid"]."'");
                while($r= mysqli_fetch_array($query)){
                    
                $product=$r["p_name"];
                $price=$r["price"];
                $qty=$r["quantity"];
                $amt=$r["productamount"];
                $total=$r["totalamount"];
        
        $pdf->SetFont('Arial', '', 12);
        
            
                $pdf->Cell(50, 6, $product, 1, 0, 'L');
                $pdf->Cell(40, 6, $price, 1, 0, 'C');
                $pdf->Cell(50, 6, $qty, 1, 0, 'L');
                $pdf->Cell(40, 6, $amt, 1, 1, 'C');
            
        }
                $pdf->Cell(50, 6, '', 0, 0, 'L');
                $pdf->Cell(40, 6, '', 0, 0, 'C');
                $pdf->Cell(50, 6, 'Total Amount', 1, 0, 'L');
                $pdf->Cell(40, 6, $total, 1, 1, 'C');
        $pdf->Output();
        ?>
    </body>
</html>
<?php
ob_end_flush();
?>
