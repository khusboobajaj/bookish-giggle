<?php
  //session_start();
  include 'connection.php';
 ?>

<!DOCTYPE html>
<html>
  <head>
  
    <meta charset="utf-8">
    <title>Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/home.css" media="screen" title="no title" charset="utf-8">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <style media="screen">
      body{
        background-color: #f1f1f1;
      }
      .navbar-custom {
        color: #FFFFFF;
        background-color: #001;
      }
      a {
        color: grey;
      }
      .active {
        color:white;
        font-size: 1.1em;
      }
      a:hover {
        color:#f1f1f1;
      }
      .navbar-brand{
        font-size: 1.5em;
        color:#f1f1f1;
      }
      .custom-toggler.navbar-toggler {
        padding:1px;
        background-image: url("images/menu.svg");
        filter: invert(1);
      }
      .rightlink {
        transition: all 0.2s;
        -webkit-transition: all 0.2s;
        -moz-transition: all 0.2s;
      }
      .hidden {
        display: none;
      }
      .zoom {
        transition: transform .2s;
      }
      .zoom:hover {
          transform: scale(1.2);
      }
      ::-webkit-scrollbar {
        width: 10px;
      }
      ::-webkit-scrollbar-track {
        box-shadow: inset 0 0 1px rgb(0, 0, 0);
      }
      ::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 10px;
      }
      ::-webkit-scrollbar-thumb:hover {
        background: powderblue;
      }
      
 
      </style>
  </head>
  <body id="bodytag">
    <nav class="navbar sticky-top navbar-expand-lg navbar-custom">
      <div class="container">
          <a class="navbar-brand" href="#">The Watch Store</a>
        <button class="custom-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-item nav-link active" href="home.php">Home</a>
          </div>
          <div class="navbar-nav ml-auto">
              <a class="nav-item nav-link rightlink" href="RegisterLogin/login.php">Login&nbsp;<i class="fa fa-user"></i>&nbsp;&nbsp;</a>
              <a class="nav-item nav-link rightlink" href="RegisterLogin/register.php">Sign Up&nbsp;<i class="fa fa-user-plus"></i>&nbsp;&nbsp;</a>
              <a class="nav-item nav-link rightlink hidden" href="RegisterLogin/logout.php">Logout&nbsp;<i class="fa fa-sign-out"></i>&nbsp;&nbsp;</a>
              <a class="nav-item nav-link" href="RegisterLogin/login.php"><i class="fa fa-shopping-bag" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>
    </nav>

  <div style='padding-top:30px' class="container">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item">
            <a href="productview.php"><img class="d-block w-100" src="images/bnr-1.jpg" alt="First slide"></a>
        </div>
        <div class="carousel-item active">
            <a href="productview.php"><img class="d-block w-100" src="images/bnr-2.jpg" alt="Second slide"></a>
        </div>
        <div class="carousel-item">
            <a href="productview.php"><img class="d-block w-100" src="images/bnr-3.jpg" alt="Third slide"></a>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
<br>
<div class="container">
    <center><h3>Shop By Category</h3></center><br>
    <div class="row mt-4">
     
        <?php
        $count=0;
        $result = mysqli_query($conn, "select * from tbl_category");
        $check= mysqli_num_rows($result)>0;
        if($check){
            while ($row = mysqli_fetch_array($result)) {
                ?>
                
                <div class="col-md-3 mt-3">
                    <a href="categoryview.php">
                    <div class="card">
                        
                        <img src='Admin/category/<?php echo $row['image']?>' class="card-img.top" style="width:150px; height: 150px">
                        <div class="card-body">
                            
                            <h2 class="card-tilte"></h2>
                            <p class="card-text">
                                <?php echo $row['c_name'];?>
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                
                <?php
            }
        }
        else{
            echo "No record found";
        }
        ?> 
   
        </div>
      
  	</div><br><br>
    <div class="container">
        <center><h3>Shop By Watch Type</h3></center><br>
    <div class="row mt-4"><br>
        
        <?php
        $count=0;
        
       
        $result = mysqli_query($conn, "select * from tbl_watch_type");
        $check= mysqli_num_rows($result)>0;
        if($check){
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="col-md-3 mt-3">
                    <a href="watchtypeview.php">
                    <div class="card">
                        <img src='Admin/watchtype/<?php echo $row['image']?>' class="card-img.top" style="width:150px; height: 150px">
                        <div class="card-body">
                            
                            <h2 class="card-tilte"></h2>
                            <p class="card-text">
                                <?php echo $row['w_name'];?>
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                <?php
                
                
            }
        }
        else{
            echo "No record found";
        }
        ?>
    </div>
</div><br><br>

<div class="container">
    <center><h3>Shop By Brand</h3></center><br>
        <div class="row mt-4"><br>
      
        <?php
        $count=0;
        
       
        $result = mysqli_query($conn, "select * from tbl_brand");
        $check= mysqli_num_rows($result)>0;
        if($check){
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="col-md-3 mt-3">
                    <a href="brandview.php">
                    <div class="card">
                        <img src='Admin/Brands/<?php echo $row['image']?>' class="card-img.top" style="width:200px; height: 150px">
                        <div class="card-body">
                            
                            <h2 class="card-tilte"></h2>
                            <p class="card-text">
                                <?php echo $row['b_name'];?>
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                <?php
                
                
            }
        }
        else{
            echo "No record found";
        }
        ?>
      
    </div>
</div>

  <footer class="py-5 bg-light mt-auto">
                    <div class="container-fluid">
                            <center><div class="text-muted">Copyright &copy; watch store 2021</div></center>
                    </div>
  </footer>
  
  <script type="text/javascript">
    $('#myCarousel').on('slide.bs.carousel', function () {});
  </script>
  </body>
</html>
