<?php
ob_start();
    include './connection.php';
    session_start();
if($_SESSION['username']==NULL)
{
    header("Location:RegisterLogin/login.php");
}

?>
<!DOCTYPE html
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/home.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css"></script>

<style media="screen">
    .jumbotron {
      margin: 20px 40px;
    }
    .thumbnail{
      /*margin: 10px 10px;*/
      padding: 10px 10px;
      width: 70%;
      height: auto;
      align-items: center;
    }
    #borderpart{
       border: 1px solid rgba(0, 0, 0, 0.2);
       margin: 6px;
       margin-bottom: 20px;
       width: 24%;
       border-radius: 5%;
    }
    .containers {
      width: 92%;
      margin: auto;
    }
    .cntr{
      align-items: center;
      width: 50%;
    }
    .navbar-custom {
      color: #FFFFFF;
      background-color: #001;
    }
    a {
      color: grey;
    }
    .active {
      color:white;
      font-size: 1.1em;
    }
    a:hover {
      color:#f1f1f1;
    }
    .navbar-brand{
      font-size: 1.5em;
      color:#f1f1f1;
    }
    .custom-toggler.navbar-toggler {
      padding:1px;
      background-image: url("images/menu.svg");
      filter: invert(1);
    }
    .zoom {
      transition: transform .2s;
    }
    img {
      border-radius: 10%;
    }
    .zoom:hover {
        transform: scale(1.05);
    }
    ::-webkit-scrollbar {
      width: 10px;
    }
    ::-webkit-scrollbar-track {
      box-shadow: inset 0 0 1px rgb(0, 0, 0);
    }
    ::-webkit-scrollbar-thumb {
      background: rgba(0, 0, 0, 0.2);
      border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: powderblue;
    }
body {font-family: Arial, Helvetica, sans-serif;}

.product_name {
    font-size: 20px;
    font-weight: 400;
    margin-top: 0px
}
.input-group input[type="number"]{
    height: 30px;
    width: 50px;
    
}
</style>
<script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
        function ConfirmDelete()
{
  confirm("Are you sure you want to delete?");
}
    </script>
    </head>
    <body>
         <nav class="navbar sticky-top navbar-expand-lg navbar-custom ">
      <div class="container">
        <a class="navbar-brand" href="#">The Watch Store</a>
        <button class="custom-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
              <a class="nav-item nav-link" href="CustomerDashboard.php">Home</a>
          </div>
          <div class="navbar-nav">
              <a class="nav-item nav-link" href="userprofile.php">User Profile</a>
          </div>
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="contactUs.php">Contact Us</a>
          </div>
          <div class="navbar-nav ml-auto">
              <a class="nav-item nav-link" href="RegisterLogin/logout.php">Logout&nbsp;<i class="fa fa-sign-out"></i>&nbsp;&nbsp;</a>
              <a class="nav-item nav-link" href="addtocart.php"><i class="fa fa-shopping-bag" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>
    </nav>
        <div class="jumbotron">
            <center><p><h2>Please select the payment gateway here</h2></p></center>
            <center><img src="images/images.png" name="image" height="150" width="350" alt="194x228" class="img-responsive"></center><br>
            <center><form method="post">
            <table>
                        <tr>
                            <th>Payment Mode:</th>
                        </tr>
                        <tr>
                            <td><input type="radio" name="payment" value="credit" >&nbsp;&nbsp;Credit card&nbsp;&nbsp;
                                <input type="radio" name="payment" value="debit" >&nbsp;&nbsp;Debit card&nbsp;&nbsp;&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Card Number:</th>
                            <th>Card Holder Name:</th>
                            
                        </tr>
                        <tr>
                            <td><input type="tel" class="form-control" placeholder="Valid Card Number" pattern="[0-9]{12}" title="Please Enter valid number" required=""></td>
                            <td><input type="text" class="form-control" placeholder="Card Owner Name" pattern="[A-Za-z\s]{2,} [A-Za-z]{2,}" title="Please Enter valid name" required=""/></td>
                        </tr>
                        <tr>
                            <th>Expiration Date:</th>
                            <th>CVV No:</th>
                            
                        </tr>
                        <tr>
                            <td><input type="month" class="form-control" placeholder="MM / YY"  pattern="[0-1]{1}[0-9]{1}/[2]{1}[0-9]{1}" title="Please Enter valid date" required="" /></td>
                            <td><input type="password" class="form-control" placeholder="cvv number" pattern="[0-9]{3}" title="Please Enter valid cvv number" required=""/></td>
                        </tr>
                        <tr>
                            <td><input type="submit" class="btn btn-success" name="pay" value="Pay"/></td>
                        </tr>
                        
 
            </table>
            </form>
            </center>
        </div>
        <?php
        //echo $_SESSION['Total'];
        if(isset($_POST['pay'])){
            $p="select p_id,p_name,price,description,pimage from tbl_product";
                            $ps=$conn->query($p);
                            if($ps->num_rows>0)
                            {
                                
                                while($row=$ps->fetch_assoc()){
                                    $p1=$row["p_id"];
                       $pname="p".$p1;
                unset($_SESSION[$pname]);
                                }
                            }
            $uid= mysqli_query($conn,"select id from tbl_user where username='".$_SESSION['username']."'");
            $row= mysqli_fetch_array($uid);
            $userid=$row['id'];
            $sql= mysqli_query($conn,"insert into tbl_payment (payment_mode,amount,u_id) values('".$_POST['payment']."','".$_SESSION['Total']."','".$userid."')");
            $id= mysqli_query($conn,"select pay_id from tbl_payment order by pay_id desc limit 1");
            $row= mysqli_fetch_array($id);
            $payid=$row['pay_id'];
            $update= mysqli_query($conn,"update tbl_order set pay_id='".$payid."' where o_id='".$_SESSION['oid']."'");
            
            echo "<script>window.location='generatebill.php'</script>";

        }
            
        
        ?>
        
    <div class="row containers" style="display:flex;flex-wrap:wrap;">
      
      </div>
      <footer class="py-5 bg-light mt-auto">
                    <div class="container-fluid">
                            <center><div class="text-muted">Copyright &copy; watch store 2021</div></center>
                    </div>
    </footer>
      
    </body>
</html>
<?php
ob_flush();
?>


