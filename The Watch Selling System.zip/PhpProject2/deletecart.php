<?php
ob_start();
    include './connection.php';
session_start();

 $pid=$_GET["id"];
 unset($_SESSION[$pid]);




header('Location:addtocart.php');
