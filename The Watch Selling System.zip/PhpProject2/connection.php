<?php
$conn= mysqli_connect("localhost","root","") or die('error in connection');

$select= mysqli_select_db($conn,"owss") or die('database not found');
    


