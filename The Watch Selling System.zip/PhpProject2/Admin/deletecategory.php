<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            include_once '../connection.php';
                        
                        $query = "delete from tbl_category where c_id='".$_GET["id"]."'";

                        $r = mysqli_query($conn, $query);
                        
                        echo '<script>window.location="managecategory.php"</script>';
        ?>
    </body>
</html>

