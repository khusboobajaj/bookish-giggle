<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
        </style>
        
    </head>
    <body class="sb-nav-fixed">
         <?php
       include 'header.php'; // put your code here
        ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
    </head>
    <body>
     <div id="layoutSidenav_content">
                <main>
                  <form action="" class="form-group" method="post" enctype="multipart/form-data">
                    <div class="container-fluid">
                        <div class="row">
                            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">Update Brands</h1>

                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="managebrand.php">VIEW ALL BRANDS</a>
                            </div>
                        </div>
                        <!--content-->
                        <?php
                        $id = $_GET["id"];
                        $result = "select b_name,image from tbl_brand where b_id='" . $id . "'";
                        $sql = mysqli_query($conn, $result);
                        while ($row = mysqli_fetch_array($sql)) 
                        {
                        ?>
                        <table style="float:left">
                           
                            <tr>
                                <td><label for="bname">Brand Name</label></td>   
                            </tr>
                            <tr>
                                <td><input  class="form-control" type="text" name="bname" required="" value="<?php echo $row["b_name"]; ?>"></td>
                            </tr>
                           <tr>
                                <td><label for="exampleFormControlFile1">Upload Brand Image </label></td>   
                            </tr>
                            <tr>
                                <td>
                                   <input type="file" name="image">
                                 </td>
                            </tr>    
                            <tr> 
                                <td><input type="submit" class="btn btn-secondary" name="update" value="Update Brand"></td>
                            </tr>
                        </table>

                    </main>

                </div>
            </div>
        </form> 
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; watch store 2021</div>
                        </div>
                    </div>
                </footer>
            </div>
         <?php
            }
        if (isset($_POST["update"])) {
            $photo = $_FILES['image']['name'];
            $image_Path = "Brands/" . basename($photo);
            $update = "update tbl_brand set image='" . $photo . "' ,b_name='" . $_POST["bname"] . "' where b_id='" . $id . "'";

            if ($result = mysqli_query($conn, $update)) {
                if (move_uploaded_file($_FILES['image']['tmp_name'], $image_Path)) {
                    echo "Your Image uploaded successfully";
                } else {
                    echo "Not Insert Image";
                }
                echo '<script>alert("Updated succesfully")</script>';
                echo '<script>window.location="managebrand.php"</script>';
            }
        }
        ?>
    </main>
    </body>
</html>
