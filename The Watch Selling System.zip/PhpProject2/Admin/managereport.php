<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
            th{
                width:150px;
                height: 30px;
                background-color: #778899;
            }
           
        </style>
    </head>
    <body class="sb-nav-fixed">
        <?php include 'header.php'; ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
             
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Manage Reports</h1>
                        <ol class="breadcrumb mb-4">
                            <?php //echo $_SESSION['username']; ?>&nbsp;<li class="breadcrumb-item active">Manage Reports</li>
                        </ol>

                    </div>
                    
         <form action="" class="form-group" method="post" enctype="multipart/form-data">
                    <div class="container-fluid">
                        <div class="row">
                            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">generate Report</h1>

                        </div>
                        <!--content-->
                        <table style="float:left">
                           
                            <tr>
                                <td><img src="../images/report.jpg" alt=""/></td>
                                <td>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                </td>
                                <td>
                                    <table border="1">
                                        <thead>
                                            <tr>
                                            <th>Product Name</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <?php
                                         if (isset($_POST["view"])) {
                                            $month = $_POST["month"];
                                            echo "<h3>Report for " . $month . " Month</h3>";
                                            $sql = mysqli_query($conn, "SELECT DISTINCT tbl_product.p_name,MONTHNAME(tbl_order.order_date) as monthname FROM tbl_reference_order
INNER JOIN tbl_order ON tbl_order.o_id=tbl_reference_order.o_id
INNER JOIN tbl_orderdetails ON tbl_orderdetails.od_id=tbl_reference_order.od_id
INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id
WHERE MONTHNAME(tbl_order.order_date)='$month'");
                                            while ($row = mysqli_fetch_array($sql)) {
                                                $product = $row["p_name"];
                                                $order = $row["monthname"];
                                                $query = mysqli_query($conn, "SELECT DISTINCT tbl_product.p_name,SUM(tbl_orderdetails.quantity) as totalqty,tbl_product.price,(SUM(tbl_orderdetails.quantity)*tbl_product.price) as totalprice
FROM tbl_orderdetails
INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id
INNER JOIN tbl_reference_order on tbl_reference_order.od_id=tbl_orderdetails.od_id
inner join tbl_order on tbl_order.o_id=tbl_reference_order.o_id

WHERE tbl_product.p_name='$product' and MONTHNAME(tbl_order.order_date)='$order'");
                                                while ($r = mysqli_fetch_array($query)) {
                                                    ?>

            <tbody>
                <tr>
                    <td><?php echo $r["p_name"];?></td>
                    <td><?php echo $r["price"];?></td>
                    <td><?php echo $r["totalqty"];?></td>
                    <td><?php echo $r["totalprice"];?></td>
                </tr>
            </tbody>
       
        <?php
        }
        }
       
    
            }
?>
                                        
                                    </table >
                                </td>
                            </tr>
                            <tr>
                                <td><label for="exampleFormControlFile1">Select Month</label></td>   
                            </tr>
                            <tr>
                                <td>
                                    <select class="form-control" name="month">
                                       <option disable="" selected>--Select Month--</option>
                                       <option>January</option>
                                       <option>February</option>
                                       <option>March</option>
                                       <option>April</option>
                                       <option>May</option>
                                       <option>June</option>
                                       <option>July</option>
                                       <option>August</option>
                                       <option>September</option>
                                       <option>October</option>
                                       <option>November</option>
                                       <option>December</option>
                
                                    </select><br>
                                 </td>
                            </tr>    
                            <tr> 
                                <td><input type="submit" class="btn btn-secondary" name="view" value="View Report"></td>
                            </tr>
                        </table>

                    </main>

                </div>
            </div>
        </form>
      
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; watch store 2021</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>
