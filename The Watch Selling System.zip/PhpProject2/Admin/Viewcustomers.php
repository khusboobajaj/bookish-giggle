<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style>
            table{

                margin-top:100px;
            }
            th{
                width:150px;
                height: 30px;
                background-color: #778899;
            }
            td{
                width:150px;
                height: 30px;
                background-color: #f7f6f6;
            }

            body {font-family: Arial, Helvetica, sans-serif;}

            .navbar {
                width: 100%;
                background-color: #555;
                overflow: auto;
            }

            .navbar a {
                float: left;
                padding: 12px;
                color: white;
                text-decoration: none;
                font-size: 17px;
            }

            .navbar a:hover {
                background-color:black;
            }

            .active {
                background-color: #778899;
            }


            .navbar a {
                float: left;
                display: block;
            }

            .footer{
                position: relative;
                bottom: 0;
                left:0;
                width: 99%;
                background-color: #555;

                display:block;
                padding: 12px;
                color: white;
                text-align: center;

            }
            .footer a{
                padding: 12px;
                color: white;
                text-decoration: none;
                font-size: 17px;
            }


            .navbar-right{float: right;
                          margin-right: 10px;
            }
            input[type=submit]{
                margin-top:10px;
                background: #2ecc71;
                margin-left: 450px;
                text-align: center;
                border: 2px solid ;
                padding: 14px 35px;
                outline: none;
                color: white;
                border-radius: 8px;
                transition: 1.0 s;
                cursor: pointer;
            }

        </style>
        <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
        function ConfirmDelete()
        {
            confirm("Are you sure you want to delete?");
        }
    </script>
    
    </head>
    <body class="sb-nav-fixed">
        <?php include 'header.php'; ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
             
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">View all Orders</h1>
                        <ol class="breadcrumb mb-4">
                            <?php //echo $_SESSION['username']; ?>&nbsp;<li class="breadcrumb-item active">view orders</li>
                        </ol>
                    </div>
                    
                 <center>
                     <form>
                    <table border="0">
                        <?php
                        
                        $query="select * from tbl_user";
                        $r = mysqli_query($conn, $query);
                        ?>
                        
                        <thead>
                            
                               <tr><h2>All Registered Customers</h2></tr>
                            <tr>
                                <th>User Id</th>
                                <th>Name</th>
                                <th>Gender</th>
                                <th>Address</th>
                                <th>Pincode</th>
                                <th>Birt date</th>
                                <th>Email Id</th>
                                <th>Contact Number</th>
                                <th>Username</th>
                            </tr>
                           
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_array($r)) {
                                echo "<tr>";
                                echo "<td>" . $row["id"] . "</td>";
                                echo "<td>" . $row["Name"] . "</td>";
                                echo "<td>" . $row["Gender"] . "</td>";
                                echo "<td>" . $row["Address"] . "</td>";
                                 echo "<td>" . $row["Pincode"] . "</td>";
                                echo "<td>" . $row["DOB"] . "</td>";
                                echo "<td>" . $row["Email_id"] . "</td>";
                                echo "<td>" . $row["Contact_no"] . "</td>";
                                echo "<td>" . $row["Username"] . "</td>";
                            echo "</tr>";}
                            ?>
                        </tbody>     
                    </table>
                    </form>
            </center>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; watch store 2021</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>


