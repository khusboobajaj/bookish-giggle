<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
        </style>
        
    </head>
    <body class="sb-nav-fixed">
         <?php
       include 'header.php'; // put your code here
        ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
    <?php
   // The preg_match() function searches a string for pattern, returning
    //   true if the pattern exists, and false otherwise.
        $nameErr=$priceErr=$sizeErr=$quantityErr=$desErr=$bErr=$cErr=$sErr="";
        $name=$price=$size=$qty=$des=$b=$c=$s="";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["product"])) {
                $nameErr = "Product Name is required";
            } else {
                $name = test_input($_POST["product"]);
                // check if name only contains letters and whitespace
                if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
                    $nameErr = "Only letters and white space allowed";
                }
            }
             if (empty($_POST["price"])) {
                $priceErr = "Price is required";
            } 
            /*else{if(!preg_match("/^\d+(\.\d{2})?$/", $price)) {
                    $priceErr = "Only Numbers allowed";
                }
            }*/
                if (empty($_POST["size"])) {
                $sizeErr = "Size is required";
            } 
            
            if (empty($_POST["des"])) {
                $desErr = "Description is required";
            }else{ 
                if (!preg_match("/^[a-zA-Z ]*$/", $des)) {
                    $desErr = "Only letters and white space allowed";
            }
            
            }
               if (empty($_POST["brand"])) {
                $bErr = "Please select brand";
            } 
            if (empty($_POST["category"])) {
                $cErr = "Please select category";
            } 
            if (empty($_POST["sport"])) {
                $sErr = "Please select sport type";
            } 
        }
        function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>
    <body>
        <div id="layoutSidenav_content">
    <main>
        <form action="" class="form-group" method="post" enctype="multipart/form-data">
            <div class="container-fluid">
                <div class="row">
                    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">update Product</h1>

                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="manageproduct.php">VIEW ALL PRODUCTS</a>
                            </div>
                        </div>
                        <?php
                        $id = $_GET["id"];
                        $result = "select p_name,price,description,quantity from tbl_product where p_id='" . $id . "'";
                        $sql = mysqli_query($conn, $result);
                        while ($row = mysqli_fetch_array($sql)) {
                            ?>
                        <table style="float:left">
                            <tr>
                                <td><label for="input-pname">Product name</label></td>

                                <td><label for="input-price">Product Price</label></td>
                            </tr>
                            <tr>
                                <td><input class="form-control" type="text" name="product" value="<?php echo $row["p_name"]; ?>" /><span class="error"> <?php echo $nameErr; ?></span>

                                </td>
                                <td><input  class="form-control" type="text" name="price" value="<?php echo $row["price"]; ?>"><span class="error"> <?php echo $priceErr; ?></span></td>
                            </tr>
                            <tr>
                                <td><label for="input-description">Description</label></td>
                            </tr>
                            <tr>
                                <td colspan="2"><input class="form-control"  type="text" name="description" value="<?php echo $row["description"]; ?>"><span class="error"> <?php echo $desErr; ?></span></td>
                            </tr>
                            <tr><td>
                            <label>Brand:</label>
            <select name="brand" class="form-control">
                <option disable selected>--Select Brand--</option>
                <?php 
                $result=mysqli_query($conn,"select * from tbl_brand");
                while($row=mysqli_fetch_array($result))
                {
              ?>    
                    
                    <option value=<?php echo $row["b_id"]; ?>><?php echo $row["b_name"]; ?></option>
               <?php     
                }
            ?>
                    </select><br><span class="error"> <?php echo $bErr; ?></span></td>
                                <td>
                            <label>Category:</label>
            <select name="category" class="form-control">
                <option disable selected>--Select Category--</option>
                <?php 
                $result=mysqli_query($conn,"select * from tbl_category");
                while($row=mysqli_fetch_array($result))
                {
              ?>    
                    
                    <option value=<?php echo $row["c_id"]; ?>><?php echo $row["c_name"]; ?></option>
               <?php     
                }
            ?>
                    </select><br><span class="error"> <?php echo $bErr; ?></span></td></tr>
                            <tr><td>
                            <label>Watch Type:</label>
            <select name="type" class="form-control">
                <option disable selected>--Select Watch type--</option>
                <?php 
                $result=mysqli_query($conn,"select * from tbl_watch_type");
                while($row=mysqli_fetch_array($result))
                {
              ?>    
                    
                    <option value=<?php echo $row["w_id"]; ?>><?php echo $row["w_name"]; ?></option>
               <?php     
                }
            ?>
            </select><br><span class="error"> <?php echo $bErr; ?></span></td>
                            </tr>    
                            <tr>
                                
                                <td><input type="submit" class="btn btn-secondary" name="update" value="Update Product"></td>
                            </tr>
                        </table>

                    </main>
                        </div>
                </div>
            </div>
        </form> 
         <?php
                        }
        if (isset($_POST["update"])) {
            
            $update = "update tbl_product set p_name='" . $_POST["product"] . "',price='" . $_POST["price"] . "',description='" . $_POST["description"] . "' where p_id='" . $id . "'";

            if ($result = mysqli_query($conn, $update)) {
                if (move_uploaded_file($_FILES['image']['tmp_name'], $image_Path)) {
                    echo "Your Image uploaded successfully";
                } else {
                    echo "Not Insert Image";
                }
                echo '<script>alert("Updated succesfully")</script>';
                echo '<script>window.location="manageproduct.php"</script>';
            }
        }
        ?>
    </main>
    </body>
</html>

