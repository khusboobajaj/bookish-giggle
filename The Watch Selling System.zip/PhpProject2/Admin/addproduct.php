<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
 ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <title>Add Product</title>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
            
            .footer{
                position: relative;
                bottom: 0;
                left:0;
                width: 99%;
                background-color: #555;

                display:block;
                padding: 12px;
                color: white;
                text-align: center;

            }
            .footer a{
                padding: 12px;
                color: white;
                text-decoration: none;
                font-size: 17px;
            }

        </style>
    </head>
    <body>
         <body class="sb-nav-fixed">
         <?php
       include 'header.php'; // put your code here
        ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
                    <?php
   // The preg_match() function searches a string for pattern, returning
    //   true if the pattern exists, and false otherwise.
        $nameErr=$priceErr=$sizeErr=$quantityErr=$desErr=$bErr=$cErr=$sErr="";
        $name=$price=$size=$qty=$des=$b=$c=$s="";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["product"])) {
                $nameErr = "Product Name is required";
            } else {
                $name = test_input($_POST["product"]);
                // check if name only contains letters and whitespace
                if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
                    $nameErr = "Only letters and white space allowed";
                }
            }
             if (empty($_POST["price"])) {
                $priceErr = "Price is required";
            } 
            /*else{if(!preg_match("/^\d+(\.\d{2})?$/", $price)) {
                    $priceErr = "Only Numbers allowed";
                }
            }*/
                if (empty($_POST["size"])) {
                $sizeErr = "Size is required";
            } 
            if (empty($_POST["qty"])) {
                $quantityErr = "Quantity is required";
            }
            if (empty($_POST["des"])) {
                $desErr = "Description is required";
            }else{ 
                if (!preg_match("/^[a-zA-Z ]*$/", $des)) {
                    $desErr = "Only letters and white space allowed";
            }
            
            }
               if (empty($_POST["brand"])) {
                $bErr = "Please select brand";
            } 
            if (empty($_POST["category"])) {
                $cErr = "Please select category";
            } 
            if (empty($_POST["sport"])) {
                $sErr = "Please select sport type";
            } 
        }
        function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>
            <div id="layoutSidenav_content">
                <main>
                  <form action="" class="form-group" method="post" enctype="multipart/form-data">
                    <div class="container-fluid">
                        <div class="row">
                            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">Add Product</h1>

                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="manageproduct.php">VIEW ALL PRODUCTS</a>
                            </div>
                        </div>
                        <!--content-->

                        <table style="float:left">
                            <tr>
                                <td><label for="input-pname">Product name</label></td>

                                <td><label for="input-price">Product Price</label></td>
                            </tr>
                            <tr>
                                <td><input class="form-control" type="text" name="product" /><span class="error"> <?php echo $nameErr; ?></span>

                                </td>
                                <td><input  class="form-control" type="text" name="price"><span class="error"> <?php echo $priceErr; ?></span></td>
                            </tr>
                            <tr>
                                <td><label for="input-description">Description</label></td>
                            </tr>
                            <tr>
                                <td colspan="2"><input class="form-control"  type="text" name="description"><span class="error"> <?php echo $desErr; ?></span></td>
                            </tr>
                            <tr>
                                
                                <td><label for="qty">Quantity</label></td>
                            </tr>
                            
                            <tr>
                               

                                <td><input class="form-control" type="text" name="pqty" required=""><span class="error"> <?php echo $quantityErr; ?></span></td>
                            </tr>
                            <tr><td>
                            <label>Brand:</label>
            <select name="brand" class="form-control">
                <option disable selected>--Select Brand--</option>
                <?php 
                $result=mysqli_query($conn,"select * from tbl_brand");
                while($row=mysqli_fetch_array($result))
                {
              ?>    
                    
                    <option value=<?php echo $row["b_id"]; ?>><?php echo $row["b_name"]; ?></option>
               <?php     
                }
            ?>
                    </select><br><span class="error"> <?php echo $bErr; ?></span></td>
                                <td>
                            <label>Category:</label>
            <select name="category" class="form-control">
                <option disable selected>--Select Category--</option>
                <?php 
                $result=mysqli_query($conn,"select * from tbl_category");
                while($row=mysqli_fetch_array($result))
                {
              ?>    
                    
                    <option value=<?php echo $row["c_id"]; ?>><?php echo $row["c_name"]; ?></option>
               <?php     
                }
            ?>
                    </select><br><span class="error"> <?php echo $bErr; ?></span></td></tr>
                            <tr><td>
                            <label>Watch Type:</label>
            <select name="type" class="form-control">
                <option disable selected>--Select Watch type--</option>
                <?php 
                $result=mysqli_query($conn,"select * from tbl_watch_type");
                while($row=mysqli_fetch_array($result))
                {
              ?>    
                    
                    <option value=<?php echo $row["w_id"]; ?>><?php echo $row["w_name"]; ?></option>
               <?php     
                }
            ?>
                    </select><br><span class="error"> <?php echo $bErr; ?></span></td>
                                <td><label for="exampleFormControlFile1">Upload Product Image </label></td>   
                            
                                <td>
                                    <input type="file" name="image">
                                 </td>
                            </tr>    
                            <tr>
                                
                                <td><input type="submit" class="btn btn-secondary" name="addproduct" value="Add new Product"></td>
                            </tr>
                        </table>

                    </main>
                        </div>
                </div>
            </div>
        </form> 
            
            
        <?php 
            if(isset($_POST["addproduct"]))
            {
                $images = $_FILES["image"]["name"];
                if (file_exists("product/" . $_FILES["image"]["name"])) {
            $store = $_FILES["image"]["name"];
            echo '<script>alert("Image already exists !")</script>';
        } else {
            if($nameErr=="" )
                {
                //$cid="select c_id from tbl_category where category_name='".$row["category"]."'";
                $query="insert into tbl_product (p_name,price,quantity,description,c_id,b_id,w_id,pimage) values('".$_POST["product"]."','".$_POST["price"]."','".$_POST["pqty"]."','".$_POST["description"]."','".$_POST["category"]."','".$_POST["brand"]."','".$_POST["type"]."','$images')";
               
               if ($result = mysqli_query($conn, $query)) {
                    move_uploaded_file($_FILES["image"]["tmp_name"], "product/" . $_FILES["image"]["name"]);
                   echo '<script>alert("Inserted succesfully")</script>';
                   echo '<script>window.location="manageproduct.php"</script>';
               }else
               {
                   echo '<script>alert("Not Inserted succesfully")</script>';
               }
                }
        }
            
            }
        ?>
           
                    
    </body>
</html>
