<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <title>Add Product</title>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
        </style>
    </head>
    <body>
        <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="dashboard.php">watch Store</a>
            <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
            
            <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <div class="input-group">
                    <div class="input-group-append">
                        <a class="navbar-brand"  href="../RegisterLogin/logout.php">&nbsp;&nbsp;&nbsp;&nbsp;LogOut&nbsp;&nbsp;<i class="fa fa-power-off" aria-hidden="true"></i></a>
                    </div>
                </div>
            </form>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">User</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt" style="font-size:20px"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Manage Details</div>
                            <a class="nav-link collapsed" href="manageproduct.php">          
                                <div class="sb-nav-link-icon"><i class='fas fa-dice-d6' style='font-size:20px'></i></div>
                                Manage Products
                                
                            </a>
                            <a class="nav-link collapsed" href="managecategory.php">
                                <div class="sb-nav-link-icon"><i class="far fa-clone" style='font-size:20px'></i></div>
                                Manage Categories
                                
                            </a>
                            <a class="nav-link collapsed" href="managebrand.php">
                                <div class="sb-nav-link-icon"><i class='fas fa-layer-group'  style='font-size:20px'"></i></div>
                                Manage brands
                                
                            </a>
                            <a class="nav-link collapsed" href="managewatchtype.php">
                                <div class="sb-nav-link-icon"><i class=" fas fa-stopwatch" style='font-size:20px'"></i></div>
                                Manage Watch Type
                                
                            </a>
                            <a class="nav-link collapsed" href="managestock.php">
                                <div class="sb-nav-link-icon"><i class='fas fa-boxes' style='font-size:19px'></i></div>
                                Manage Stock
                                
                            </a>
                            <a class="nav-link collapsed" href="managereport.php" >
                                <div class="sb-nav-link-icon"><i style="font-size:24px" class="fa">&#xf15c;</i></div>
                                Generate reports
                            </a>
                            <a class="nav-link collapsed" href="vieworders.php" >
                                <div class="sb-nav-link-icon"><i class="fas fa-luggage-cart" style="font-size:20px"></i></div>
                                View Orders
                            </a>
                            <a class="nav-link collapsed" href="Viewcustomers.php" >
                                <div class="sb-nav-link-icon"><i class="fas fa-users" style="font-size:20px"></i></div>
                                View Customers
                            </a>
                            <a class="nav-link collapsed" href="managefeedback.php">     
                                <div class="sb-nav-link-icon"><i class="  far fa-star" style="font-size:20px"></i></div>
                                Manage Feedback
                            </a>
                        </div>
                    </div>
    </body>
</html>
