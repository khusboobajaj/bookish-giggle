<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
 ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <title>Add Product</title>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
        </style>
    </head>
    <body>
        
         <?php
       include 'header.php'; // put your code here
        ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
                    <?php
   // The preg_match() function searches a string for pattern, returning
    //   true if the pattern exists, and false otherwise.
        $widthErr=$lengthErr=$straptypeErr=$psourceErr=$agegrpErr=$wcolorErr=$cErr=$sErr="";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["width"])) {
                $widthErr = "width is required";
            } 
                
            }
             if (empty($_POST["length"])) {
                $lengthErr = "length is required";
            } 
            /*else{if(!preg_match("/^\d+(\.\d{2})?$/", $price)) {
                    $priceErr = "Only Numbers allowed";
                }
            }*/
                if (empty($_POST["straptype"])) {
                $straptypeErr = "Strap type is required";
            } 
            if (empty($_POST["psource"])) {
                $psourceErr = "power source is required";
            }
            if (empty($_POST["agegrp"])) {
                $agegrpErr = "Age group is required";
            }
            
            
            if (empty($_POST["wcolor"])) {
                $wcolorErr = "Please enter watch colour";
            } 
           
            function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>
            <div id="layoutSidenav_content">
                <main>
                  <form action="" class="form-group" method="post" enctype="multipart/form-data">
                    <div class="container-fluid">
                        <div class="row">
                            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">Add Product Specifications</h1>

                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="manageproduct.php">VIEW ALL PRODUCTS</a>
                            </div>
                        </div>
                        <!--content-->

                        <table style="float:left">
                            <tr>
                                <td><label for="input-width">Product width</label></td>

                                <td><label for="input-length">Product length</label></td>
                            </tr>
                            <tr>
                                <td><input class="form-control" type="text" name="width" /><span class="error"> <?php echo $widthErr; ?></span></td>
                                <td><input  class="form-control" type="text" name="length"><span class="error"> <?php echo $lengthErr; ?></span></td>
                            </tr>
                            <tr>
                                <td><label for="input-description">Strap type</label></td>
                                 <td><label for="input-psource">Power source</label></td>
                            </tr>
                            <tr>
                                <td><input class="form-control"  type="text" name="straptype"><span class="error"> <?php echo $straptypeErr; ?></span></td>
                                <td><input class="form-control" type="text" name="psource" required=""><span class="error"> <?php echo $psourceErr; ?></span></td>
                            </tr>
                             <tr>
                                
                                <td><label for="input-age group">Age Group</label></td>
                                 <td><label for="input-watch colour">watch Colour</label></td>
                            </tr>
                            
                            <tr>
                               

                                <td><input class="form-control" type="text" name="agegrp" required=""><span class="error"> <?php echo $agegrpErr; ?></span></td>
                                 <td><input class="form-control" type="text" name="wcolor" required=""><span class="error"> <?php echo $wcolorErr; ?></span></td>
                            </tr>
              
                                
                                <td><input type="submit" class="btn btn-secondary" name="addspecification" value="Add Product specification"></td>
                            </tr>
                        </table>
                        </form>
                    </main>
                        </div>
                </div>
            </div>
            
            
        <?php 
            if(isset($_POST["addspecification"]))
            {
                $sql="insert into tbl_specification (width,length,strap_type,power_source,color,age_group,p_id) values ('".$_POST["width"]."','".$_POST["length"]."','".$_POST["straptype"]."','".$_POST["psource"]."','".$_POST["wcolor"]."','".$_POST["agegrp"]."','".$_GET["id"]."') ";
            
                if($result=mysqli_query($conn,$sql))
                {
                    echo '<script>alert("Inserted succesfully")</script>';
                    echo '<script>window.location="manageproduct.php"</script>';
                }
                else
                {
                    echo '<script>alert("Not Inserted succesfully")</script>';
                }
                
            }
        
        ?>
      
    </body>
</html>

