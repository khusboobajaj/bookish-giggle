<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
        <style>
            table{

                margin-top:100px;
            }
            th{
                width:150px;
                height: 30px;
                background-color: #778899;
            }
            td{
                width:150px;
                height: 30px;
                background-color: #f7f6f6;
            }

            body {font-family: Arial, Helvetica, sans-serif;}

            .navbar {
                width: 100%;
                background-color: #555;
                overflow: auto;
            }

            .navbar a {
                float: left;
                padding: 12px;
                color: white;
                text-decoration: none;
                font-size: 17px;
            }

            .navbar a:hover {
                background-color:black;
            }

            .active {
                background-color: #778899;
            }


            .navbar a {
                float: left;
                display: block;
            }

            .footer{
                position: relative;
                bottom: 0;
                left:0;
                width: 99%;
                background-color: #555;

                display:block;
                padding: 12px;
                color: white;
                text-align: center;

            }
            .footer a{
                padding: 12px;
                color: white;
                text-decoration: none;
                font-size: 17px;
            }


            .navbar-right{float: right;
                          margin-right: 10px;
            }
            input[type=submit]{
                margin-top:10px;
                background: #2ecc71;
                margin-left: 450px;
                text-align: center;
                border: 2px solid ;
                padding: 14px 35px;
                outline: none;
                color: white;
                border-radius: 8px;
                transition: 1.0 s;
                cursor: pointer;
            }

        </style>
        <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
        function ConfirmDelete()
        {
            confirm("Are you sure you want to delete?");
        }
    </script>
    
    </head>
    <body class="sb-nav-fixed">
        <?php include 'header.php'; ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
             
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">View all Orders</h1>
                        <ol class="breadcrumb mb-4">
                            <?php //echo $_SESSION['username']; ?>&nbsp;<li class="breadcrumb-item active">view orders</li>
                        </ol>
                    </div>
                    
                 <center>
                     <form>
                    <table border="0">
                        <?php
                        
                        $query="SELECT tbl_product.p_name,tbl_product.price,tbl_orderdetails.quantity,tbl_orderdetails.amount as productamount,tbl_order.status, tbl_order.amount as totalamount,tbl_order.order_date,CONCAT(tbl_user.Name) as name,tbl_payment.payment_mode FROM tbl_reference_order INNER JOIN tbl_orderdetails ON tbl_orderdetails.od_id=tbl_reference_order.od_id INNER JOIN tbl_order ON tbl_reference_order.o_id=tbl_order.o_id INNER JOIN tbl_product ON tbl_product.p_id=tbl_orderdetails.p_id INNER JOIN tbl_user ON tbl_order.u_id=tbl_user.id INNER JOIN tbl_payment ON tbl_payment.pay_id=tbl_order.pay_id where tbl_order.status='Confirm'";
                        $r = mysqli_query($conn, $query);
                        ?>
                        
                        <thead>
                            
                               <tr><h2>Order Details</h2></tr>
                            <tr>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th >Amount</th>
                                <th >Status</th>
                                <th >Order date</th>
                                <th >Customer Name</th>
                                <th >Total Amount</th>
                                <th>Payment Mode</th>
 
                            </tr>
                           
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_array($r)) {
                                echo "<tr>";
                                echo "<td>" . $row["p_name"] . "</td>";
                                echo "<td>" . $row["price"] . "</td>";
                                echo "<td>" . $row["quantity"] . "</td>";
                                echo "<td>" . $row["productamount"] . "</td>";
                                 echo "<td>" . $row["status"] . "</td>";
                                echo "<td>" . $row["order_date"] . "</td>";
                                echo "<td>" . $row["name"] . "</td>";
                                echo "<td>" . $row["totalamount"] . "</td>";
                                echo "<td>" . $row["payment_mode"] . "</td>";
                            echo "</tr>";}
                            ?>
                        </tbody>     
                    </table>
                    </form>
            </center>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; watch store 2021</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>

