<?php
include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <title>Add Product</title>
        <style>
            td{padding: 2px;}
            .error {color: #FF0000;}
        </style>
    </head>
    <body>
    <body class="sb-nav-fixed">
        <?php
        include 'header.php'; // put your code here
        ?>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Admin
        </div>
    </nav>
</div>
<?php
// The preg_match() function searches a string for pattern, returning
//   true if the pattern exists, and false otherwise.
$nameErr = $imageErr = "";
$name = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["cname"])) {
        $nameErr = "Category Name is required";
    } else {
        $name = test_input($_POST["category"]);
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            $nameErr = "Only letters and white space allowed";
        }
    }
    if (empty($_POST["cimage"])) {
        $imageErr = "Please select Image";
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
<div id="layoutSidenav_content">
    <main>
        <form action="" class="form-group" method="post" enctype="multipart/form-data">
            <div class="container-fluid">
                <div class="row">
                    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">Add Category</h1>

                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="managecategory.php">VIEW ALL Categories</a>
                            </div>
                        </div>
                        <!--content-->

                        <table style="float:left">

                            <tr>
                                <td><label for="category">Category Name</label></td>   
                            </tr>
                            <tr>
                                <td><input  class="form-control" type="text" name="cname" required=""></td><span class="error"> <?php echo $nameErr; ?></span><br><br>
                            </tr>
                            <tr>
                                <td><label for="exampleFormControlFile1">Upload Category Image </label></td>   
                            </tr>
                            <tr>
                                <td>
                                    <input type="file" name="image" value="Upload"><span class="error"> <?php echo $imageErr; ?></span><br><br>
                                </td>
                            </tr>    
                            <tr>

                                <td><input type="submit" class="btn btn-secondary" name="addcategory" value="Add new Category"></td>
                            </tr>
                        </table>

                    </main>

                </div>
            </div>
        </form> 
    </main>
    <?php
    if (isset($_POST["addcategory"])) {
        $cname = $_POST["cname"];
        $images = $_FILES["image"]["name"];
        if (file_exists("category/" . $_FILES["image"]["name"])) {
            $store = $_FILES["image"]["name"];
            echo '<script>alert("Image already exists !")</script>';
        } else {
            $query = "insert into tbl_category (image,c_name) values('$images','$cname')";
            if (mysqli_query($conn, $query)) {
                move_uploaded_file($_FILES["image"]["tmp_name"], "category/" . $_FILES["image"]["name"]);
                echo '<script>alert("Inserted succesfully")</script>';
                echo '<script>window.location="managecategory.php"</script>';
            } else {
                echo '<script>alert("Not Inserted")</script>';
            }
        }
    }
    ?>
    <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid">
            <div class="d-flex align-items-center justify-content-between small">
                <div class="text-muted">Copyright &copy; watch store 2021</div>
            </div>
        </div>
    </footer>
</div>

<?php ?>
</body>
</html>