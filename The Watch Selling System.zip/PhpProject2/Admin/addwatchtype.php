<?php
    include '../connection.php';
    session_start();
    if(($_SESSION['username']==null))
    {
         echo "<script>window.location='../RegisterLogin/login.php'</script>";
    }
 ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
        <title>Dashboard - WS Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        
    </head>
    <body>
         <body class="sb-nav-fixed">
         <?php
       include 'header.php';
        ?>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                       Admin
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                  <form action="" class="form-group" method="post" enctype="multipart/form-data">
                    <div class="container-fluid">
                        <div class="row">
                            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                            <h1 class="h2">Add watch Types</h1>

                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="managewatchtype.php">VIEW ALL WATCH TYPES</a>
                            </div>
                        </div>
                        <!--content-->

                        <table style="float:left">
                           
                            <tr>
                                <td><label for="wtype">Watch Type</label></td>   
                            </tr>
                            <tr>
                                <td><input  class="form-control" type="text" name="wtype" required=""></td>
                            </tr>
                           <tr>
                                <td><label for="exampleFormControlFile1">Upload Watch Type Image </label></td>   
                            </tr>
                            <tr>
                                <td>
                                   <input type="file" name="image">
                                 </td>
                            </tr>    
                            <tr>
                                
                                <td><input type="submit" class="btn btn-secondary" name="addtype" value="Add new watch Type"></td>
                            </tr>
                        </table>

                    </main>

                </div>
            </div>
        </form> 
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; watch store 2021</div>
                        </div>
                    </div>
                </footer>
            </div>
            
        <?php
        if (isset($_POST["addtype"])) {
        $wtype = $_POST["wtype"];
        $images = $_FILES["image"]["name"];
        if (file_exists("watchtype/" . $_FILES["image"]["name"])) {
            $store = $_FILES["image"]["name"];
            echo '<script>alert("Image already exists !")</script>';
        } else {
            $query = "insert into tbl_watch_type (image,w_name) values('$images','$wtype')";
            if (mysqli_query($conn, $query)) {
                move_uploaded_file($_FILES["image"]["tmp_name"], "watchtype/" . $_FILES["image"]["name"]);
                echo '<script>alert("Inserted succesfully")</script>';
                echo '<script>window.location="managewatchtype.php"</script>';
            } else {
                echo '<script>alert("Not Inserted")</script>';
            }
        }
    }
        ?>
    </body>
</html>

